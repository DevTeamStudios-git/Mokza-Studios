/* ========================================================================
   MOKZA STUDIOS — APPLICATION LOGIC
   ======================================================================== */

/* ── STATE ── */
const state = {
  currentPage: 'home',
  theme: 'light',
  devModeActive: false,
  currentUser: null,
  announcements: [],
  suggestions: [],
  projects: [],
  tasks: [],
  chatMessages: [],
  activityLog: [],
  featureCards: {
    home: [], about: [], contact: [], community: [], roblox: [], creations: []
  },
  navigationLinks: [
    { id: 'nav_home', label: 'Home', page: 'home', enabled: true, author: 'System', minRank: null },
    { id: 'nav_about', label: 'About Us', page: 'about', enabled: true, author: 'System', minRank: null },
    { id: 'nav_contact', label: 'Contact', page: 'contact', enabled: true, author: 'System', minRank: null },
    { id: 'nav_community', label: 'Community', page: 'community', enabled: true, author: 'System', minRank: null },
    { id: 'nav_roblox', label: 'Roblox', page: 'roblox', enabled: true, author: 'System', minRank: null },
    { id: 'nav_creations', label: 'Creations', page: 'creations', enabled: true, author: 'System', minRank: null },
    { id: 'nav_workspace', label: 'Workspace', page: 'workspace', enabled: true, author: 'System', minRank: 'Apprentice' }
  ],
  pageViews: {},
  raidMode: false
};

const USERS = {
  'ThéoDevO': { passwordHash: '0dfc6b27a925b6c5e47750a47906abc201310200dd01a82d6a683f96e4e41605', rank: 'Owner', permissions: 'ALL' },
  'GabrielDevCoO': { passwordHash: 'eaf5607c0ae46bd62bc68689a42b7a11e57d3f17ed60c26d399857d5bb59d6b8', rank: 'CoOwner', permissions: 'ALL' },
  'NeuraXIDev': { passwordHash: 'f74590b85aa9394eb675739ab1364e795059599bcc6bf31b1491268459ab02ee', rank: 'Developer', permissions: 'DEVELOPER' },
  'AprenticeDev': { passwordHash: '7d94c0ca4536bae28c3de2a369bfe303a3f2a8081196ed5dab0578769c321487', rank: 'Apprentice', permissions: 'APPRENTICE' }
};

const AUTH_MAX_ATTEMPTS = 5;
const AUTH_LOCKOUT_MS = 60000;
let _authAttempts = 0;
let _authLockedUntil = 0;

/* ── SVG ICON HELPERS ── */
function svgIcon(name, size = 24, color = 'currentColor') {
  const icons = {
    'game': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2z"/></svg>',
    'robot': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M9 10H7a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-2m12 0h-2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-2"/></svg>',
    'computer': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M12 18h.01M8 21h8a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2z"/></svg>',
    'chart': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'clipboard': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><rect x="8" y="6" width="8" height="12" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></svg>',
    'memo': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
    'chat': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    'wrench': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l1.6 1.6a1 1 0 0 0 1.4 1.4l-7.6-7.6a1 1 0 0 0-1.4-1.4l-1.6-1.6a1 1 0 0 0-1.4-1.4l-1.6-1.6a1 1 0 0 0-1.4-1.4l-1.6-1.6a1 1 0 0 0-1.4-1.4z"/><path d="M11 14l4-4m0 0l-4-4m4 4l4 4"/></svg>',
    'chart-up': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'lock': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    'unlock': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/><path d="M7 7h5"/></svg>',
    'trash': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    'plus': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    'pencil': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M17 3l4 4M3.5 17.5l2.7 2.7M3 17.5v-1a1 1 0 0 1 1-1h4.5a1 1 0 0 1 1 1V21a1 1 0 0 0 1 1h4.5a1 1 0 0 0 1-1v-4.5a1 1 0 0 0-1-1H14a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1z"/></svg>',
    'building': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="21"/><line x1="15" y1="21" x2="15" y2="21"/></svg>',
    'save': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8"/><polyline points="21 13 17 17"/><polyline points="17 13 14 14"/></svg>',
    'inbox': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><polyline points="7 17 12 12 17 17"/><polyline points="7 6 12 11 17 6"/><line x1="12" y1="17" x2="12" y2="11"/><line x1="2 17" x2="22" y2="17"/><line x1="2 11" x2="22" y2="11"/></svg>',
    'outbox': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><polyline points="17 7 12 12 7 7"/><polyline points="7 17 12 12 17 17"/><line x1="12" y1="17" x2="12" y2="7"/><line x1="2 17" x2="22" y2="17"/><line x1="2 11" x2="22" y2="11"/></svg>',
    'broom': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M5 17h14v2H5z"/><line x1="5" y1="17" x2="5.183" y2="16.817"/></svg>',
    'gear': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 1-1-1.51V21a2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 1 9 19.4a1.65 1.65 0 0 1-1.51 1H3a2 2 0 0 1-2-2v-.09a1.65 1.65 0 0 1 0-3.42v-.09a1.65 1.65 0 0 1 1-1.51a1.65 1.65 0 0 1 1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 1 1-1.51 1.65 1.65 0 0 1 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 1-1 1.51V3a2 2 0 0 1 2-2h.09a1.65 1.65 0 0 1 1.51 1H21a2 2 0 0 1 2 2v.09a1.65 1.65 0 0 1-1.51 1z"/></svg>',
    'x-mark': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    'bell': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
    'rocket': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
    'people': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>',
    'sparkles': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M20.925 12.204a1 1 0 0 1-.835 0l-.889-.445a1 1 0 0 0-.166-1.17l-.35-.889a1 1 0 0 0-1.17-.166L17.2 9.59a1 1 0 0 0 0-1.17l-.445-.889a1 1 0 0 0-1.17-.166L14.2 7.343a1 1 0 0 0-1.17 0l-.445.889a1 1 0 0 0-.166 1.17l-.35.889a1 1 0 0 0 0 1.17l.889.445a1 1 0 0 1 .835 0l.889-.445a1 1 0 0 1 1.17.166l.35.889a1 1 0 0 0 1.17.166l.445-.889a1 1 0 0 1 .166-1.17zM10 13a1 1 0 1 0 0-2V3a1 1 0 1 0 0 2zM21 13a1 1 0 1 0 0-2v-8a1 1 0 1 0 0 2z"/></svg>',
    'target': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
    'construction': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M9 17h6v2H9z"/><path d="M9 3v2h6V3zm-2 4h10v10H7z"/><path d="M9 3V1v2h6V3z"/></svg>',
    'search': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    'person': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    'sun': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
    'moon': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
    'circle-green': '<circle cx="'+size/2+'" cy="'+size/2+'" r="'+size/4+'" fill="#38ef7d"/>',
    'download': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    'upload': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 10 12 15 7 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    'cloud': '<svg width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="'+color+'" stroke-width="2"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>'
  };
  return icons[name] || '<span style="font-size:'+size+'px">?</span>';
}
  if (typeof str !== 'string') return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#x27;');
}

function canAccess(rank) {
  const ranks = { Owner: 3, CoOwner: 2, Developer: 1, Apprentice: 0 };
  const userRank = state.currentUser ? ranks[state.currentUser.rank] : -1;
  return userRank >= ranks[rank];
}

function showNotification(title, message, type = 'info') {
  const container = document.getElementById('notificationContainer');
  const id = Date.now();
  const notif = document.createElement('div');
  notif.className = 'notification ' + type;
  var icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
  notif.innerHTML = '<div class="notification-icon">' + icon + '</div><div class="notification-content"><div class="notification-title">' + escHtml(title) + '</div><div class="notification-message">' + escHtml(message) + '</div></div>';
  container.appendChild(notif);
  setTimeout(function() {
    notif.style.animation = 'slideOutRight 0.3s ease forwards';
    setTimeout(function() { if (container.contains(notif)) container.removeChild(notif); }, 300);
  }, 4000);
}

function logActivity(action, details) {
  state.activityLog.unshift({ id: Date.now(), user: state.currentUser ? state.currentUser.username : 'System', action: action, details: details, timestamp: new Date().toLocaleString() });
  if (state.activityLog.length > 50) state.activityLog = state.activityLog.slice(0, 50);
}

/* ── AUTH ── */
async function sha256(message) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(message));
  return Array.from(new Uint8Array(buf)).map(function(b) { return b.toString(16).padStart(2, '0'); }).join('');
}

function isAuthLocked() {
  if (_authLockedUntil && Date.now() < _authLockedUntil) return true;
  if (_authLockedUntil && Date.now() >= _authLockedUntil) { _authAttempts = 0; _authLockedUntil = 0; }
  return false;
}

async function handleAuthSubmit() {
  if (isAuthLocked()) {
    var remaining = Math.ceil((_authLockedUntil - Date.now()) / 1000);
    showNotification('Locked', 'Too many attempts. Try again in ' + remaining + 's', 'error');
    return;
  }
  var code = document.getElementById('securityCodeInput').value;
  var hashed = await sha256(code);
  var SECURITY_CODE_HASH = 'bbf426ea8e5c0bf78035833c75064f60f810db695c3b4f16cecbe3ac5c20e957';
  if (hashed !== SECURITY_CODE_HASH) {
    _authAttempts++;
    showNotification('Failed', 'Wrong code. ' + (AUTH_MAX_ATTEMPTS - _authAttempts) + ' attempt(s) left', 'error');
    if (_authAttempts >= AUTH_MAX_ATTEMPTS) {
      _authLockedUntil = Date.now() + AUTH_LOCKOUT_MS;
      logActivity('Security', 'Auth locked after too many failed attempts');
    }
    return;
  }
  var username = document.getElementById('usernameInput').value.trim();
  var password = document.getElementById('passwordInput').value;
  var user = USERS[username];
  if (!user) { showNotification('Failed', 'Invalid credentials', 'error'); return; }
  var pwhash = await sha256(password);
  if (pwhash !== user.passwordHash) {
    _authAttempts++;
    showNotification('Failed', 'Invalid credentials', 'error');
    return;
  }
  _authAttempts = 0; _authLockedUntil = 0;
  state.currentUser = { username: username, rank: user.rank, permissions: user.permissions };
  state.devModeActive = true;
  document.getElementById('devToggle').classList.add('active');
  closeAuthModal();
  showNotification('Welcome!', 'Logged in as ' + username + ' (' + user.rank + ')', 'success');
  logActivity('User Login', username + ' logged in');
  renderPage();
}

function showAuthModal() {
  document.getElementById('authModal').classList.remove('hidden');
  document.getElementById('authModal').innerHTML = '<div class="modal"><div class="modal-header"><h2>Developer Authentication</h2><button class="modal-close" onclick="closeAuthModal()">svgIcon('x-mark', 20)</button></div><div class="modal-body"><div class="label-base">Security Code</div><input type="password" id="securityCodeInput" class="input-base" placeholder="Enter security code" /><div class="label-base" style="margin-top:1rem;">Credentials</div><input type="text" id="usernameInput" class="input-base" placeholder="Username" /><input type="password" id="passwordInput" class="input-base" placeholder="Password" /><div class="modal-footer"><button class="btn-primary" onclick="handleAuthSubmit()">Login</button><button class="btn-ghost" onclick="closeAuthModal()">Cancel</button></div></div></div>';
}

function closeAuthModal() {
  document.getElementById('authModal').classList.add('hidden');
}

function handleLogout() {
  state.currentUser = null;
  state.devModeActive = false;
  document.getElementById('devToggle').classList.remove('active');
  showNotification('Logged Out', 'Successfully logged out', 'info');
  logActivity('User Logout', 'User logged out');
  renderPage();
}

function toggleDevMode() {
  if (!state.devModeActive) showAuthModal();
  else handleLogout();
}

/* ── API ── */
async function apiRequest(path, options) {
  options = options || {};
  options.headers = options.headers || {};
  options.headers['Content-Type'] = 'application/json';
  const res = await fetch('/api' + path, options);
  if (!res.ok) throw new Error('API ' + res.status);
  return res.json();
}

async function saveToFirestore() {
  var payload = Object.assign({}, state, { savedAt: new Date().toISOString() });
  try { await apiRequest('/website-state/save', { method: 'POST', body: { data: payload } }); }
  catch (e) { console.warn('Save failed:', e.message); }
}

async function loadFromFirestore() {
  try {
    var result = await apiRequest('/website-state');
    if (result.state) { Object.assign(state, result.state); return true; }
  } catch (e) { console.warn('Load failed:', e.message); }
  return false;
}

/* ── NAVIGATION ── */
function renderNavigation() {
  var nav = document.getElementById('navbarLinks');
  var mobile = document.getElementById('mobileNavLinks');
  var enabled = state.navigationLinks.filter(function(l) { return l.enabled && (!l.minRank || canAccess(l.minRank)); });
  var html = enabled.map(function(l) {
    var badge = l.minRank ? '<span class="badge badge-blue">' + l.minRank + '+</span>' : '';
    return '<button class="nav-link ' + (state.currentPage === l.page ? 'active' : '') + '" onclick="changePage(\'' + l.page + '\')"><span>' + l.label + '</span>' + badge + '</button>';
  }).join('');
  nav.innerHTML = html;
  mobile.innerHTML = enabled.map(function(l) {
    return '<button class="mobile-nav-link ' + (state.currentPage === l.page ? 'active' : '') + '" onclick="changePage(\'' + l.page + '\');closeMobileNav();">' + l.label + '</button>';
  }).join('');
}

function changePage(page) {
  state.currentPage = page;
  state.pageViews[page] = (state.pageViews[page] || 0) + 1;
  renderNavigation();
  renderPage();
}

function toggleMobileNav() {
  var drawer = document.getElementById('mobileNavDrawer');
  var overlay = document.getElementById('mobileNavOverlay');
  var isOpen = drawer.classList.contains('open');
  drawer.classList.toggle('open', !isOpen);
  overlay.classList.toggle('open', !isOpen);
}
function closeMobileNav() {
  document.getElementById('mobileNavDrawer').classList.remove('open');
  document.getElementById('mobileNavOverlay').classList.remove('open');
}

/* ── PAGE RENDERING ── */
function renderPage() {
  var content = document.getElementById('pageContent');
  var announcements = state.announcements.filter(function(a) { return a.type === 'all' || state.currentUser; });
  var annHtml = announcements.length > 0 ? '<div class="announcements-banner">' + announcements.map(function(a) {
    return '<div class="announcement ' + a.type + '"><div class="announcement-header"><span class="announcement-type ' + a.type + '">' + (a.type === 'staff' ? 'svgIcon('people', 20) STAFF' : '📢 ALL') + '</span></div><div class="announcement-title">' + escHtml(a.title) + '</div><div class="announcement-content">' + escHtml(a.content) + '</div></div>';
  }).join('') + '</div>' : '';
  switch (state.currentPage) {
    case 'home': content.innerHTML = renderHome(annHtml); break;
    case 'about': content.innerHTML = renderAbout(); break;
    case 'contact': content.innerHTML = renderContact(); break;
    case 'community': content.innerHTML = renderCommunity(); break;
    case 'roblox': content.innerHTML = renderRoblox(); break;
    case 'creations': content.innerHTML = renderCreations(); break;
    case 'workspace': content.innerHTML = renderWorkspace(); break;
  }
}

function renderHome(annHtml) {
  return '<div class="hero"><div class="hero-bg"></div><div class="hero-content"><div class="hero-badge">svgIcon('sparkles', 20) Mokza Studios</div><h1 class="hero-title">Building the Future</h1><p class="hero-subtitle">Independent game studio creating exceptional digital experiences, Roblox projects, and more.</p><div class="hero-actions"><button class="btn btn-primary">View Projects</button><button class="btn btn-outline">Join Community</button></div><div class="hero-stats"><div class="stat-card"><div class="stat-number">' + state.projects.length + '</div><div class="stat-label">Projects</div></div><div class="stat-card"><div class="stat-number">' + state.tasks.filter(function(t){return !t.done;}).length + '</div><div class="stat-label">Open Tasks</div></div><div class="stat-card"><div class="stat-number">' + state.announcements.length + '</div><div class="stat-label">Announcements</div></div></div></div></div><div class="features-grid"><div class="feature-card"><div class="feature-icon">svgIcon('game', 20)</div><h3>Game Development</h3><p>Creating original, engaging, and memorable gaming experiences.</p><a href="#" class="feature-link">Explore →</a></div><div class="feature-card"><div class="feature-icon">svgIcon('robot', 20)</div><h3>Roblox Projects</h3><p>Building immersive Roblox experiences for millions of players.</p><a href="#" class="feature-link">Explore →</a></div><div class="feature-card"><div class="feature-icon">svgIcon('computer', 20)</div><h3>Software Development</h3><p>Designing, building, and deploying software solutions.</p><a href="#" class="feature-link">Explore →</a></div></div><div class="suggestions-section"><div class="suggestions-header"><h2 class="suggestions-title">💡 Share Your Suggestions</h2><p class="suggestions-description">We value your feedback! Help us improve by sharing your ideas.</p></div><div class="suggestion-form"><textarea id="suggestionInput" placeholder="Tell us your ideas, feature requests, or feedback..."></textarea><button class="btn btn-primary" onclick="submitSuggestion()">Submit Suggestion</button></div>' + (state.suggestions.length > 0 ? '<div class="suggestion-list">' + state.suggestions.slice(0,5).map(function(s) {
    return '<div class="suggestion-item"><div class="suggestion-author">' + escHtml(s.author) + '</div><div class="suggestion-text">' + escHtml(s.text) + '</div><div class="suggestion-time">' + escHtml(s.timestamp) + '</div></div>';
  }).join('') + '</div>' : '') + '</div>';
}

function renderAbout() {
  return '<div class="page-header"><h1 class="page-title">About Us</h1><p class="page-subtitle">Mokza Studios is an independent game studio focused on creating original, engaging, and memorable gaming experiences.</p></div><div class="features-grid"><div class="feature-card"><div class="feature-icon">svgIcon('target', 20)</div><h3>Our Mission</h3><p>To create original games that entertain players, inspire creativity, and leave a lasting impression.</p></div><div class="feature-card"><div class="feature-icon">svgIcon('sparkles', 20)</div><h3>Our Values</h3><p>Creativity, Quality, Originality, Community, Growth.</p></div></div>';
}

function renderContact() {
  return '<div class="page-header"><h1 class="page-title">Contact Us</h1><p class="page-subtitle">Get in touch with us for collaborations, inquiries, or just to say hello!</p></div><div class="card-bg" style="padding:2rem;border-radius:var(--radius-lg);max-width:600px;margin:0 auto;"><div class="label-base">Name</div><input type="text" class="input-base" placeholder="Your name" /><div class="label-base" style="margin-top:1rem;">Email</div><input type="email" class="input-base" placeholder="you@example.com" /><div class="label-base" style="margin-top:1rem;">Message</div><textarea class="input-base" placeholder="Your message..." rows="4"></textarea><button class="btn btn-primary" style="margin-top:1rem;width:100%;">Send Message</button></div>';
}

function renderCommunity() {
  return '<div class="page-header"><h1 class="page-title">Community</h1><p class="page-subtitle">Join our growing community of developers, designers, and creators!</p></div><div class="card-bg" style="padding:2rem;border-radius:var(--radius-lg);max-width:800px;margin:0 auto;"><p>Join our Discord server to connect with the team and other community members.</p><button class="btn btn-primary" style="margin-top:1rem;">Join Discord</button></div>';
}

function renderRoblox() {
  return '<div class="page-header"><h1 class="page-title">Roblox Projects</h1><p class="page-subtitle">Explore our Roblox game development projects and creations.</p></div><div class="projects-grid"><div class="project-card"><div class="project-image">svgIcon('game', 20)</div><div class="project-content"><div class="project-title">Mokza Adventure</div><div class="project-description">An immersive adventure game built in Roblox Studio.</div><div class="project-meta"><span>svgIcon('calendar', 20) 2026</span><span>svgIcon('person', 20) Mokza Team</span></div><div class="project-actions"><button class="btn btn-sm btn-primary">Play</button></div></div></div></div>';
}

function renderCreations() {
  var html = '<div class="page-header"><h1 class="page-title">Our Creations</h1><div class="search-bar" style="margin-bottom:2rem;"><input type="text" class="input-base" placeholder="Search projects..." style="width:100%;max-width:400px;" /><button class="btn btn-primary" style="margin-left:0.5rem;">Add Project</button></div></div><div class="projects-grid">';
  if (state.projects.length > 0) {
    state.projects.forEach(function(p) {
      html += '<div class="project-card"><div class="project-image">' + (p.image || '📦') + '</div><div class="project-content"><div class="project-title">' + escHtml(p.title) + '</div><div class="project-description">' + escHtml(p.description) + '</div><div class="project-meta"><span>svgIcon('calendar', 20) ' + p.date + '</span><span>svgIcon('person', 20) ' + escHtml(p.poster) + '</span></div>';
      if (p.link && p.link !== '#') html += '<a href="' + p.link + '" target="_blank" class="btn btn-primary" style="width:100%;">View Project</a>';
      html += '</div></div>';
    });
  } else {
    html += '<div class="empty-placeholder"><div class="empty-icon">svgIcon('construction', 20)</div><h3>No creations yet!</h3><p>Come back later — we\'re working on something great.</p></div>';
  }
  html += '</div>';
  return html;
}

function renderWorkspace() {
  if (!state.currentUser) {
    return '<div class="card-bg" style="padding:3rem;text-align:center;max-width:600px;margin:0 auto;"><div class="empty-icon">svgIcon('lock', 20)</div><h3>Staff Workspace</h3><p style="margin-bottom:1.5rem;">Mokza Nexus is our internal workspace — chat, tasks, project boards, notes, and more. It\'s restricted to signed-in team members.</p><button class="btn btn-primary" onclick="showAuthModal()">Sign In</button></div>';
  }
  return '<div class="page-header"><h1 class="page-title">Mokza Nexus Workspace</h1><p class="page-subtitle">Our internal team workspace — chat, tasks, project boards, notes, and the Software Center.</p></div><div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;margin-bottom:2rem;"><button class="btn btn-primary" onclick="closeOfficeHub();openOfficeHub()">svgIcon('building', 20) Open Office Hub</button><button class="btn btn-outline" onclick="switchHubView(\'chat\',this);closeOfficeHub();openOfficeHub()">svgIcon('chat', 20) Team Chat</button><button class="btn btn-outline" onclick="switchHubView(\'tasks\',this);closeOfficeHub();openOfficeHub()">svgIcon('memo', 20) Task Board</button></div><iframe src="workspace/index.html" title="Mokza Nexus Workspace" style="width:100%;height:600px;border:none;border-radius:var(--radius-lg);"></iframe>';
}

function submitSuggestion() {
  var inp = document.getElementById('suggestionInput');
  var text = inp.value.trim();
  if (!text) return;
  state.suggestions.unshift({ id: Date.now(), author: state.currentUser ? state.currentUser.username : 'Anonymous', text: text, timestamp: new Date().toLocaleString() });
  inp.value = '';
  showNotification('Thank You!', 'Your suggestion has been submitted', 'success');
  renderPage();
}

/* ── OFFICE HUB ── */
function openOfficeHub() {
  if (!state.currentUser) { showNotification('Login required', '', 'error'); return; }
  document.getElementById('officeHub').classList.add('open');
  switchHubView('dashboard', null);
}
function closeOfficeHub() {
  document.getElementById('officeHub').classList.remove('open');
}
function switchHubView(view, btn) {
  document.querySelectorAll('.hub-view').forEach(function(el) { el.classList.remove('active'); el.style.display = 'none'; });
  document.querySelectorAll('.hub-nav-item').forEach(function(b) { b.classList.remove('active'); });
  var el = document.getElementById('hub-view-' + view);
  if (el) { el.classList.add('active'); el.style.display = view === 'chat' ? 'block' : 'block'; }
  if (btn) btn.classList.add('active');
  if (view === 'dashboard') renderHubDash();
  else if (view === 'activity') renderHubAct();
  else if (view === 'tasks') renderHubTasks();
  else if (view === 'chat') renderHubChat();
  else if (view === 'toolbox') renderHubToolbox();
  else if (view === 'bots') renderHubBots();
  else if (view === 'analytics') renderHubAnalytics();
}

function renderHubDash() {
  var online = !!window.__firestoreOps;
  var openT = (state.tasks || []).filter(function(t) { return !t.done; }).length;
  var allF = (state.personalFiles || []).length + (state.devCloudFiles || []).length;
  var totalV = Object.values(state.pageViews || {}).reduce(function(a,b) { return a + b; }, 0);
  document.getElementById('hubDashContent').innerHTML = '<div class="hub-grid"><div class="hub-card"><h3>svgIcon('chart', 20) System Health</h3><div class="hub-card-row"><span class="dot ' + (online ? 'dot-green' : 'dot-red') + '"></span>DB: ' + (online ? 'Online' : 'Offline') + '</div><div class="hub-card-row"><span class="dot ' + (state.raidMode ? 'dot-red' : 'dot-green') + '"></span>Raid: ' + (state.raidMode ? 'ON' : 'OFF') + '</div><div class="hub-card-row"><span class="dot dot-green"></span>Cache: Active</div></div><div class="hub-card"><h3>svgIcon('people', 20) Team</h3>' + Object.entries(USERS).map(function(pair) {
    var n = pair[0], u = pair[1];
    return '<div class="hub-card-row"><span class="dot ' + (state.currentUser && state.currentUser.username === n ? 'dot-green' : 'dot-grey') + '"></span><span style="flex:1">' + escHtml(n) + '</span><span style="opacity:.45;font-size:.72rem">' + u.rank + '</span></div>';
  }).join('') + '</div><div class="hub-card"><h3>svgIcon('target', 20) Quick Stats</h3><div class="hub-stat-grid"><div><div class="hub-stat-big">' + state.projects.length + '</div><div class="hub-stat-label">Projects</div></div><div><div class="hub-stat-big">' + openT + '</div><div class="hub-stat-label">Open Tasks</div></div><div><div class="hub-stat-big">' + allF + '</div><div class="hub-stat-label">Files</div></div><div><div class="hub-stat-big">' + totalV + '</div><div class="hub-stat-label">Page Views</div></div></div></div></div><div class="hub-grid" style="grid-template-columns:1fr 1fr;"><div class="hub-card"><h3>svgIcon('clipboard', 20) Recent Activity</h3><div class="act-feed">' + (state.activityLog || []).slice(0,7).map(function(a) {
    return '<div class="act-entry"><span class="act-icon">' + (a.action.includes('Login') ? 'svgIcon('unlock', 20)' : a.action.includes('Logout') ? 'svgIcon('lock', 20)' : a.action.includes('Added') ? 'svgIcon('plus', 20)' : a.action.includes('Deleted') ? 'svgIcon('trash', 20)' : 'svgIcon('pencil', 20)') + '</span><span class="act-body"><strong>' + escHtml(a.user) + '</strong> ' + escHtml(a.details) + '</span><span class="act-time">' + escHtml(a.timestamp) + '</span></div>';
  }).join('') + '</div></div><div class="hub-card"><h3>svgIcon('robot', 20) DevTBot</h3><div class="hub-card-row"><span class="dot dot-green"></span><strong>DevTBot</strong> Online</div><div style="margin:.5rem 0;font-size:.78rem;opacity:.55">Prefix: <code style="background:rgba(255,255,255,.1);padding:.1rem .3rem;border-radius:4px">/</code></div><div style="font-size:.76rem;opacity:.45;line-height:1.6">/help /status /task /sync /clear /raid</div></div></div>';
}

function renderHubAct() {
  document.getElementById('hubActContent').innerHTML = '<h2 style="color:var(--accent-primary);font-size:1.05rem;margin-bottom:.9rem">svgIcon('clipboard', 20) Full Activity Log</h2><div class="act-feed">' + (state.activityLog || []).map(function(a) {
    return '<div class="act-entry"><span class="act-icon">' + (a.action.includes('Login') ? 'svgIcon('unlock', 20)' : a.action.includes('Logout') ? 'svgIcon('lock', 20)' : a.action.includes('Added') ? 'svgIcon('plus', 20)' : a.action.includes('Deleted') ? 'svgIcon('trash', 20)' : 'svgIcon('pencil', 20)') + '</span><div class="act-body"><strong>' + escHtml(a.user) + '</strong> ' + escHtml(a.details) + '</div><span class="act-time">' + escHtml(a.timestamp) + '</span></div>';
  }).join('') + '</div>';
}

function renderHubTasks() {
  var tasks = state.tasks || [];
  document.getElementById('hubTaskContent').innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.9rem"><h2 style="color:var(--accent-primary);font-size:1.05rem">svgIcon('memo', 20) Task Board</h2>' + (canAccess('Developer') ? '<button class="hub-qa-btn" onclick="openAddTaskModal()">+ Add Task</button>' : '') + '</div>' + (tasks.length ? tasks.map(function(t) {
    return '<div class="task-item ' + (t.done ? 'done' : '') + ' ' + t.priority + '"><div class="task-checkbox ' + (t.done ? 'checked' : '') + '" onclick="toggleTask(\'' + escHtml(t.id) + '\');renderHubTasks()">' + (t.done ? '✓' : '') + '</div><div style="flex:1;"><div class="task-title" style="' + (t.done ? 'text-decoration:line-through' : '') + '">' + escHtml(t.title) + '</div>' + (t.description ? '<div class="task-meta">' + escHtml(t.description) + '</div>' : '') + '<div class="task-meta"><span class="task-priority ' + t.priority + '">' + t.priority.toUpperCase() + '</span>' + (t.assignee ? ' · svgIcon('person', 20) ' + escHtml(t.assignee) : '') + (t.dueDate ? ' · svgIcon('calendar', 20) ' + escHtml(t.dueDate) : '') + ' · by ' + escHtml(t.author) + '</div></div>' + (canAccess('Developer') ? '<button class="btn-icon" onclick="deleteTask(\'' + escHtml(t.id) + '\');renderHubTasks()" style="color:#f5576c;font-size:1rem">svgIcon('trash', 20)</button>' : '') + '</div>';
  }).join('') : '<div style="text-align:center;padding:3rem;opacity:.4">No tasks yet</div>');
}

function openAddTaskModal() {
  var modal = document.getElementById('elementModal');
  if (!modal) {
    document.body.insertAdjacentHTML('beforeend', '<div id="elementModal" class="modal-overlay hidden"><div class="modal"><div class="modal-header"><h2 id="elementModalTitle">Modal</h2><button class="modal-close" onclick="closeElementModal()">svgIcon('x-mark', 20)</button></div><div class="modal-body" id="elementModalContent"></div><div class="modal-footer"><button class="btn-primary" onclick="saveTask()">Save Task</button><button class="btn-ghost" onclick="closeElementModal()">Cancel</button></div></div>');
  }
  document.getElementById('elementModalTitle').textContent = 'Add Task';
  document.getElementById('elementModalContent').innerHTML = '<div class="label-base">Title *</div><input type="text" id="taskTitle" class="input-base" placeholder="Fix the login bug" /><div class="label-base" style="margin-top:1rem;">Priority</div><select id="taskPriority" class="input-base" style="width:100%;"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select>';
  document.getElementById('elementModal').classList.remove('hidden');
}
function closeElementModal() { document.getElementById('elementModal')?.classList.add('hidden'); }
function saveTask() {
  var title = document.getElementById('taskTitle').value.trim();
  if (!title) return;
  state.tasks.unshift({ id: 'task_' + Date.now(), title: title, priority: document.getElementById('taskPriority').value, author: state.currentUser.username, done: false, createdAt: new Date().toISOString() });
  closeElementModal();
  saveToFirestore();
  renderHubTasks();
  renderPage();
  showNotification('Task Added', title, 'success');
}
function toggleTask(id) {
  var t = (state.tasks || []).find(function(t) { return t.id === id; });
  if (t) { t.done = !t.done; saveToFirestore(); renderHubTasks(); }
}
function deleteTask(id) {
  if (!confirm('Delete this task?')) return;
  state.tasks = (state.tasks || []).filter(function(t) { return t.id !== id; });
  saveToFirestore();
  renderHubTasks();
}

/* ── CHAT ── */
function renderHubChat() {
  renderHubChatChannels();
  renderHubChatMsgs();
  renderHubChatMembers();
  var inp = document.getElementById('chatInputEl');
  if (inp) {
    var ok = canAccess('Developer');
    inp.disabled = !ok;
    inp.placeholder = ok ? 'Message #general...' : 'Read-only in this channel';
  }
}
function renderHubChatChannels() {
  var el = document.getElementById('chatChannelList');
  if (!el) return;
  el.innerHTML = '<button class="chat-channel-btn active" onclick="renderHubChatMsgs();renderHubChatChannels()">#general</button><button class="chat-channel-btn" onclick="renderHubChatMsgs();renderHubChatChannels()">#announcements</button><button class="chat-channel-btn" onclick="renderHubChatMsgs();renderHubChatChannels()">#bot-commands</button>' + (canAccess('CoOwner') ? '<button class="chat-channel-btn" onclick="renderHubChatMsgs();renderHubChatChannels()">#staff-only</button>' : '');
}
function renderHubChatMsgs() {
  var el = document.getElementById('chatMsgsArea');
  if (!el) return;
  var msgs = state.chatMessages.slice(-100);
  if (!msgs.length) { el.innerHTML = '<div style="text-align:center;opacity:.38;padding:2.5rem;font-size:.88rem">No messages yet. Say hello! 👋</div>'; return; }
  el.innerHTML = msgs.map(function(m) {
    var rankCls = m.isBot ? 'is-bot' : m.rank === 'Owner' ? 'is-owner' : m.rank === 'CoOwner' ? 'is-coowner' : '';
    var badge = m.isBot ? '<span class="verified-badge gold">BOT</span>' : (m.rank === 'Owner' || m.rank === 'CoOwner') ? '<span class="verified-badge gold">VERIFIED</span>' : (m.rank === 'Developer') ? '<span class="verified-badge blue">VERIFIED</span>' : '';
    return '<div class="chat-message"><div class="chat-avatar" style="background:' + (m.isBot ? '#764ba2' : 'var(--accent-primary)') + '">' + (m.from || '?')[0].toUpperCase() + '</div><div class="chat-msg-body"><div class="chat-msg-meta"><span class="chat-author ' + rankCls + '">' + escHtml(m.from) + badge + '</span><span class="chat-time">' + escHtml(m.t || '') + '</span></div><div class="chat-text">' + escHtml(m.text).replace(/\n/g, '<br>').replace(/`([^`]+)`/g, '<code>$1</code>') + '</div></div></div>';
  }).join('');
  el.scrollTop = el.scrollHeight;
}
function renderHubChatMembers() {
  var el = document.getElementById('chatMemberList');
  if (!el) return;
  el.innerHTML = '<div class="chat-member-lbl">Online</div>' + (state.currentUser ? '<div class="chat-member-row"><span class="dot dot-green"></span>' + escHtml(state.currentUser.username) + '</div>' : '') + '<div class="chat-member-lbl" style="margin-top:.4rem">Members</div>' + Object.keys(USERS).filter(function(n) { return n !== state.currentUser?.username; }).map(function(n) {
    return '<div class="chat-member-row" style="opacity:.52"><span class="dot dot-grey"></span>' + escHtml(n) + '</div>';
  }).join('');
}
function handleChatKey(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMsg(); } }
function sendChatMsg() {
  if (!state.currentUser) { showNotification('Login required', '', 'error'); return; }
  var inp = document.getElementById('chatInputEl');
  var text = (inp?.value || '').trim();
  if (!text) return;
  if (!canAccess('Developer')) { showNotification('No permission', 'Cannot send here', 'error'); return; }
  var msg = { id: 'm' + Date.now(), from: state.currentUser.username, rank: state.currentUser.rank, text: text, t: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), isBot: false };
  state.chatMessages.push(msg);
  inp.value = '';
  renderHubChatMsgs();
  if (text.startsWith('/')) setTimeout(function() { devTBot(text.slice(1), '#general'); }, 500);
}

/* ── DEVTBOT ── */
function devTBot(cmd, ch) {
  var parts = cmd.trim().split(' ');
  var name = parts[0].toLowerCase();
  var args = parts.slice(1).join(' ');
  if (name === 'help') {
    botMsg('Available commands:', ch, '<b>/help</b> — Show commands<br><b>/status</b> — Site status<br><b>/task add &lt;title&gt;</b> — Create task<br><b>/task list</b> — List open tasks<br><b>/sync</b> — Force cloud sync (Co-Owner+)<br><b>/clear</b> — Clear channel (Co-Owner+)<br><b>/raid on|off</b> — Toggle raid mode (Co-Owner+)');
  } else if (name === 'status') {
    botMsg('svgIcon('chart', 20) Status', ch, 'svgIcon('circle-green', 20, '#38ef7d') DB: ' + (window.__firestoreOps ? 'Online' : 'Offline') + '<br>svgIcon('lock', 20) Raid: ' + (state.raidMode ? 'ON' : 'OFF') + '<br>📁 Projects: ' + state.projects.length + '<br>svgIcon('memo', 20) Open Tasks: ' + (state.tasks || []).filter(function(t) { return !t.done; }).length);
  } else if (name === 'task') {
    if (args.startsWith('add ')) {
      var title = args.slice(4).trim();
      if (title && canAccess('Developer')) {
        state.tasks.unshift({ id: 'task_' + Date.now(), title: title, description: '', priority: 'medium', assignee: '', dueDate: '', author: state.currentUser.username, done: false, createdAt: new Date().toISOString() });
        saveToFirestore();
        botMsg('Task created: **' + escHtml(title) + '**', ch);
      } else if (!canAccess('Developer')) botMsg('Requires Developer+ rank', ch);
    } else if (args === 'list') {
      var open = (state.tasks || []).filter(function(t) { return !t.done; });
      botMsg('Open tasks: ' + open.length, ch, open.slice(0, 5).map(function(t) { return '• ' + escHtml(t.title) + ' [' + t.priority + ']'; }).join('<br>') || 'No open tasks! 🎉');
    }
  } else if (name === 'sync') {
    if (canAccess('CoOwner')) { saveToFirestore(); botMsg('Sync triggered!', ch); }
    else botMsg('Requires Co-Owner+ rank', ch);
  } else if (name === 'clear') {
    if (canAccess('CoOwner')) { state.chatMessages = []; renderHubChatMsgs(); botMsg('Channel cleared.', ch); }
    else botMsg('Requires Co-Owner+ rank', ch);
  } else if (name === 'raid') {
    if (canAccess('CoOwner')) {
      var on = args === 'on';
      state.raidMode = on;
      saveToFirestore();
      botMsg((on ? '🚨 Raid Mode ENABLED' : '✅ Raid Mode DISABLED') + ' by ' + state.currentUser.username, ch);
    } else botMsg('Requires Co-Owner+ rank', ch);
  } else {
    botMsg('Unknown command "/' + escHtml(name) + '". Type /help.', ch);
  }
}
function botMsg(text, ch, embed) {
  var m = { id: 'b' + Date.now(), from: 'DevTBot', rank: 'Bot', text: text, t: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), isBot: true, embed: embed || null };
  state.chatMessages.push(m);
  renderHubChatMsgs();
}

/* ── TOOLBOX ── */
function renderHubToolbox() {
  document.getElementById('hubToolContent').innerHTML = '<h2 style="color:var(--accent-primary);font-size:1.05rem;margin-bottom:.9rem">svgIcon('wrench', 20) Developer Toolbox</h2><div class="toolbox-grid"><button class="toolbox-btn" onclick="saveToFirestore();showNotification(\'Synced\',\'\',\'success\')"><span class="tb-icon">svgIcon('cloud', 20)</span>Force Sync</button><button class="toolbox-btn" onclick="exportWebsiteState()"><span class="tb-icon">svgIcon('inbox', 20)</span>Export</button><button class="toolbox-btn" onclick="importWebsiteState()"><span class="tb-icon">svgIcon('outbox', 20)</span>Import</button><button class="toolbox-btn" onclick="hubClearCache()"><span class="tb-icon">svgIcon('broom', 20)</span>Clear Cache</button><button class="toolbox-btn" onclick="if(confirm(\'Reset analytics?\')){state.pageViews={};saveToFirestore();renderHubAnalytics();}"><span class="tb-icon">svgIcon('chart', 20)</span>Reset Analytics</button></div>';
}
function hubClearCache() {
  if (!confirm('Clear localStorage? Page will reload.')) return;
  localStorage.removeItem('mokza_state_v2');
  showNotification('Cache Cleared', 'Reloading...', 'info');
  setTimeout(function() { location.reload(); }, 1200);
}

/* ── BOTS ── */
function renderHubBots() {
  document.getElementById('hubBotContent').innerHTML = '<h2 style="color:var(--accent-primary);font-size:1.05rem;margin-bottom:.9rem">svgIcon('robot', 20) Bot Manager</h2><div class="hub-card"><h3>Built-in Bot</h3><div class="hub-card-row"><span class="dot dot-green"></span><strong>DevTBot</strong> — cannot be deleted</div><div style="margin-top:.6rem;font-size:.77rem;opacity:.5">Prefix: <code style="background:rgba(255,255,255,.1);padding:.1rem .3rem;border-radius:4px">/</code> &nbsp;|&nbsp; help status task sync clear raid</div></div>';
}

/* ── ANALYTICS ── */
function renderHubAnalytics() {
  var views = state.pageViews || {};
  var total = Object.values(views).reduce(function(a, b) { return a + b; }, 0);
  document.getElementById('hubAnalContent').innerHTML = '<h2 style="color:var(--accent-primary);font-size:1.05rem;margin-bottom:.9rem">svgIcon('chart-up', 20) Analytics</h2><div class="analytics-grid"><div class="analytics-card"><div class="analytics-value">' + total + '</div><div class="analytics-label">Total Views</div></div><div class="analytics-card"><div class="analytics-value">' + state.projects.length + '</div><div class="analytics-label">Projects</div></div><div class="analytics-card"><div class="analytics-value">' + (state.tasks || []).filter(function(t) { return !t.done; }).length + '</div><div class="analytics-label">Open Tasks</div></div></div>';
}

/* ── SETTINGS ── */
function openSettings() {
  document.getElementById('settingsPanel').classList.add('open');
  renderSettingsSection('general');
}
function closeSettings() { document.getElementById('settingsPanel').classList.remove('open'); }
function renderSettingsSection(id) {
  var el = document.getElementById('settingsContent');
  if (!el) return;
  var sections = {
    general: '<h3>svgIcon('gear', 20) General</h3><div class="s-row"><div class="s-info"><div class="s-name">Theme</div><div class="s-desc">Light / Dark (personal)</div></div><div class="s-ctrl"><select class="s-select" onchange="applyHubTheme(this.value)"><option value="light" ' + (state.theme === 'light' ? 'selected' : '') + '>svgIcon('sun', 20) Light</option><option value="dark" ' + (state.theme === 'dark' ? 'selected' : '') + '>svgIcon('moon', 20) Dark</option></select></div></div>',
    security: '<h3>svgIcon('lock', 20) Security</h3><div class="s-row"><div class="s-info"><div class="s-name">Raid Mode</div><div class="s-desc">Lock site to public</div></div><div class="s-ctrl"><label class="s-toggle"><input type="checkbox" ' + (state.raidMode ? 'checked' : '') + ' onchange="state.raidMode=this.checked;saveToFirestore()"><div class="s-toggle-track"></div></label>' + (canAccess('CoOwner') ? '' : '<span class="s-lock">svgIcon('lock', 20) CoOwner+</span>') + '</div></div>',
    data: '<h3>svgIcon('save', 20) Data & Backup</h3><div class="s-row"><div class="s-info"><div class="s-name">Export JSON</div><div class="s-desc">Download full site data</div></div><div class="s-ctrl"><button class="hub-qa-btn" onclick="exportWebsiteState()">svgIcon('inbox', 20) Export</button>' + (canAccess('Developer') ? '' : '<span style="opacity:.38">Dev+</span>') + '</div></div><div class="s-row"><div class="s-info"><div class="s-name">Import JSON</div><div class="s-desc">Restore from backup</div></div><div class="s-ctrl"><button class="hub-qa-btn" onclick="importWebsiteState()">svgIcon('outbox', 20) Import</button>' + (canAccess('CoOwner') ? '' : '<span style="opacity:.38">CoOwner+</span>') + '</div></div>',
    devtools: '<h3>svgIcon('wrench', 20) Developer Tools</h3><div class="s-row"><div class="s-info"><div class="s-name">Force Firestore Sync</div><div class="s-desc">Push all data to cloud now</div></div><div class="s-ctrl"><button class="hub-qa-btn" onclick="saveToFirestore();showNotification(\'Synced\',\'\',\'success\')">svgIcon('rocket', 20) Sync</button>' + (canAccess('Developer') ? '' : '<span style="opacity:.38">Dev+</span>') + '</div></div>'
  };
  el.innerHTML = sections[id] || '<div style="opacity:.4">Section not found</div>';
}
function applyHubTheme(v) {
  state.theme = v;
  document.getElementById('app').className = 'app ' + v;
  localStorage.setItem('mokza_theme_forced', v);
  saveToFirestore();
  renderPage();
}

/* ── EXPORT/IMPORT ── */
function exportWebsiteState() {
  var data = Object.assign({}, state, { exportDate: new Date().toISOString() });
  var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'mokza-backup-' + Date.now() + '.json';
  a.click();
  URL.revokeObjectURL(url);
  showNotification('Export Complete', 'Website data exported successfully', 'success');
}
function importWebsiteState() {
  var input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = function(e) {
    var file = e.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(event) {
      try {
        var importData = JSON.parse(event.target.result);
        if (confirm('This will replace all current data. Continue?')) {
          Object.assign(state, importData);
          saveToFirestore();
          showNotification('Import Complete', 'Website data imported successfully', 'success');
          renderNavigation();
          renderPage();
        }
      } catch (error) { showNotification('Import Failed', 'Invalid file format', 'error'); }
    };
    reader.readAsText(file);
  };
  input.click();
}

/* ── INIT ── */
async function init() {
  await loadFromFirestore();
  renderNavigation();
  renderPage();
  logActivity('System', 'Website initialized');
}
init();
